#!/bin/bash

echo "###### PLEASE RUN THIS FILE AS ROOT ######"

sudo apt-get install apache2 -y
sudo apt-get install ntfs-3g
sudo apt-get install python3

sudo python3 -m pip install Django

sudo apt-get install libapache2-mod-wsgi-py3
sudo apt-get install iptables-persistent -y

iptables -I INPUT -p tcp -m tcp --dport 80 -j ACCEPT
iptables -I INPUT -p tcp -m tcp --dport 443 -j ACCEPT

pip3 install django-axes
pip3 install pyAesCrypt
pip3 install django-session-timeout
pip3 install django-crispy-forms
pip3 install sorl-thumbnail

echo "####### APACHE CONFIGURATION SETUP ########"

cp -f armacloud.conf /etc/apache2/sites-available/

a2ensite armacloud
sudo systemctl reload apache2

sudo chown -R ../ArmaCloud
sudo chown -R www-data:www-data *

echo "#####  ARMACLOUD #########"

python3 manage.py migrate

python3 manage.py createsuperuser

