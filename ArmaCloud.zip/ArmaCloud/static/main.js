Dropzone.autoDiscover = false;

const myDropzone = new Dropzone("#my-dropzone", {
    maxFiles: 20,
    maxFilesize: 1000,
    preventDuplicates: true,
    createImageThumbnails: true,
    thumbnailWidth: 100,
    thumbnailHeight: 100,
    clickable: true,
    dicDuplicateFile: "Duplicate Files Cannot Be Uploaded",
    dictDefaultMessage: "Drag & Drop files here to upload",
    dictFallbackMessage: "Your browser does not support drag and drop file upload",
    dictFileTooBig: "File is too big ({{filesize}}MB). Max filesize: {{maxFilesize}}MB.",
    dictInvalidFileType: "You can't upload files of this type.",
    dictReponseError: "Server responded with {{statusCode}} code.",
    dictCancelUpload: "Cancel upload",
    dictCancelUploadConfirmation: "Are you sure you want to cancel this upload?",
    dictRemoveFile: "Remove",
    dictMaxFilesExceeded: "You can only upload {{maxFiles}} files.",
    init: function(){
        this.on("addedfile", function(file){
           // myDropzone.emit("thumbnail", file, "upload/");
           //  myDropzone.createThumbnailFromUrl(file, "upload/"); 
        });
        this.on("success", function(file, reponse){
            alert("File is successfully uploaded");
        });
        this.on("complete", function(file){
            myDropzone.removeFile(file);
        });
        this.on("sending", function(file, xhr, formData){
            formData.append("filesize", file.size);
        });
    },
});

//myDropzone.on("addedfile", function(file) {
//    myDropzone.emit("thumbnail", file.thumbnail, "upload/");
//    myDropzone.createThumbnailFromUrl(file, "upload/");
//});

myDropzone.on("sending", function(file, xhr, formData) {
   formData.append("filesize", file.size);
});

