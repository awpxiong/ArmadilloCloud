"""ArmaCloud URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.views.generic.base import TemplateView
from docfiles.views import MainView, file_upload_view, file_download_view, upload_log_view, file_download_filter_date, file_download_filter_size, file_open_view, file_download

urlpatterns = [
    path('@rma$ecret/', admin.site.urls),
    path('fileupload/', upload_log_view, name='fileupload-view'),
    path('fileupload/upload/', file_upload_view, name='upload-view'),
    path('', include('django.contrib.auth.urls')),
    path('', TemplateView.as_view(template_name='home.html'), name='home'),
    path('filedownload/', file_download_view, name='download-view'),
    path('filedownload/download/<file_name>/', file_download, name='file_download'),
    path('filedownload/filterdate', file_download_filter_date, name='download-filter-date'),
    path('filedownload/filtersize', file_download_filter_size, name='download-filter-size'),
    path('filedownload/fileview', file_open_view, name='open-view'),
]

urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

admin.site.site_header = 'Armadillo Cloud Administrative Panel'
admin.site.site_title = 'ArmaCloud'
admin.site.index_title = 'ArmaCloud Admin Panel'
