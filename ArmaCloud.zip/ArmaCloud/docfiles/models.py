from django.db import models
from django import forms
from django.conf import settings
from django.utils import timezone
from datetime import date
from sorl.thumbnail import get_thumbnail, ImageField
from django.utils.safestring import mark_safe
import os
# Create your models here.

class File(models.Model):
     upload = models.ImageField(upload_to='images/', default='')
     fthumbnail = models.ImageField(default='')
     fextension = models.CharField(max_length=50, default='')
     fname = models.CharField(max_length=200, default='')
     fsize = models.IntegerField(default=0)
     userupload = models.CharField(max_length=100, default='')
     uploaddate = models.DateField('Upload Date', auto_now=True)
     fprivate = models.BooleanField(default='False', null=True, blank=True)

     def __str__(self):
         return str(self.upload.name)
     def filedelete(self, *args, **kwargs):
         os.remove(os.path.join(settings.MEDIA_ROOT, self.upload.name + ".aes"))
         super(File,self).delete(*args,**kwargs)
     def thumbnail(self):
         if self.upload:
             return get_thumbnail(self.upload, '100x100', quality=90)
         return None
     def admin_photo(self):
         return mark_safe('<img src="{}" width="100" />'.format(self.upload.url))
         admin_photo.short_description = 'Image'
         admin_photo.allow_tags = True
