from django.shortcuts import render
from django.views.generic import TemplateView
from django.http import HttpResponse, JsonResponse, HttpResponseNotFound
from .models import File
from django.core.files.storage import FileSystemStorage
from django.conf import settings
from django.contrib import messages
from axes.models import AccessAttempt
from ArmaCloud.settings import EMAIL_HOST_USER
from django.core.mail import send_mail, mail_admins
from datetime import date, timedelta
from os import stat, remove
import shutil
import pyAesCrypt
import os
import io

class MainView(TemplateView):
    template_name= 'docfiles/main.html'

def file_upload_view(request):
    password = "1234"
    bufferSize = 64 * 1024
    if request.method == 'POST':
       my_file = request.FILES.get('file')
       private_file = request.POST.get('privatefile')
       file_path = os.path.join("/home/pi/ArmaCloudDrive/images/", str(my_file))
       if private_file is None:
          private_file = '0'
       username = request.user.username
       File.objects.create(upload=my_file, fsize=my_file.size, fextension=my_file.content_type, fname=my_file.name, userupload=username, fprivate=private_file)
       pyAesCrypt.encryptFile(file_path, file_path + ".aes", password)
       messages.success(request, 'File uploaded successfully')
       with open(file_path, "rb") as fIn:
           with open(file_path + ".aes", "wb") as fOut:
               pyAesCrypt.encryptStream(fIn, fOut, password, bufferSize)
               os.remove(file_path)
       return HttpResponse('')
    return JsonResponse({'post':'false'})

def file_download(request, file_name):
    file_encrypted = file_name + ".aes";
    file_path=os.path.join("/home/pi/ArmaCloudDrive/images/", str(file_encrypted))
    file_decrypt_path=os.path.join("/home/pi/ArmaCloudDrive/images/", str(file_name))
    password = "1234"
    bufferSize = 64 * 1024
    if os.path.exists(file_path):
        pyAesCrypt.decryptFile(file_path, file_decrypt_path, password, bufferSize)
        with open(file_decrypt_path, "rb") as fIn: 
            response=HttpResponse(fIn.read(),content_type="application/upload")
            response['Content-Disposition']='attachment;filename='+os.path.basename(file_name) 
            return response
    return HttpResponseNotFound('FILE NOT FOUND')

def file_download_view(request):
    username = request.user.username
    all_files = File.objects.filter(fprivate__contains='0')
    files_count = File.objects.filter(fprivate__contains='0').count()
    pfiles_count = File.objects.filter(fprivate__contains='1').filter(userupload__contains=username).count()
    print(files_count)
    print(pfiles_count)
    all_pfiles = File.objects.filter(fprivate__contains='1').filter(userupload__contains=username)
    return render(request,'docfiles/download.html', {'all':all_files, 'pall':all_pfiles, 'allcount':files_count, 'pallcount':pfiles_count})

def file_open_view(request):
    filename = request.GET['filename']
    fileupload = request.GET['fileupload']
    fileext = request.GET['filetype']
    password = "1234"
    bufferSize = 64 * 1024
    file_path = os.path.join(settings.MEDIA_ROOT, fileupload)
    file_encrypted = fileupload + ".aes"
    file_encrypted_path = os.path.join(settings.MEDIA_ROOT, file_encrypted)
    if os.path.exists(file_encrypted_path):
       pyAesCrypt.decryptFile(file_encrypted_path, file_path, password, bufferSize)
       with open(file_path,'r')as pdf:
           try:
               response = HttpResponse(pdf, content_type=fileext)
               response['Content-Disposition']='inline;filename='+os.path.basename(file_path)
               os.remove(file_path)
               return response
           except Exception:
               os.remove(file_path)
               return HttpResponseNotFound('File Error, Unable to view specific file')
    else:
       return HttpResponseNotFound('The requested file was not found in our server.')

def file_download_filter_date(request):
    is_private = request.GET['private']
    username = request.user.username
    date_check = request.GET['datefilterbtn']
    pdate_check = request.GET['pdatefilterbtn']
    date_filter = File.objects.filter(fprivate__contains = '0')
    date_pfilter = File.objects.filter(fprivate__contains = '1').filter(userupload__contains=username)
    if is_private == '0':
       if date_check == '1':
          date_filter = File.objects.filter(fprivate__contains = '0').order_by('-uploaddate')
          date_check = '0'
       elif date_check == '0':
          date_filter = File.objects.filter(fprivate__contains = '0').order_by('uploaddate')
          date_check = '1'
       else:
          date_check = '1'
    elif is_private == '1':
       if pdate_check == '1':
          date_pfilter = File.objects.filter(fprivate__contains = '1').filter(userupload__contains=username).order_by('-uploaddate')
          pdate_check = '0'
       elif pdate_check == '0':
          date_pfilter = File.objects.filter(fprivate__contains = '1').filter(userupload__contains=username).order_by('uploaddate')
          pdate_check = '1'
       else:
          pdate_check = '1'
    return render(request, 'docfiles/download.html', {'pall':date_pfilter, 'pdatefiltervalue':pdate_check, 'all':date_filter, 'datefiltervalue':date_check})

def file_download_filter_size(request):
    size_check = request.GET['sizefilterbtn']
    is_private = request.GET['private']
    username = request.user.username
    psize_check = request.GET['psizefilterbtn']
    size_filter = File.objects.filter(fprivate__contains = '0')
    psize_filter = File.objects.filter(fprivate__contains = '1').filter(userupload__contains=username)
    if is_private == '0':
       if size_check == '1':
          size_filter = File.objects.filter(fprivate__contains = '0').order_by('-fsize')
          size_check = '0'
       elif size_check == '0':
          size_filter = File.objects.filter(fprivate__contains = '0').order_by('fsize')
          size_check = '1'
       else:
          size_check = '1'
    elif is_private == '1':
       if psize_check == '1':
          psize_filter = File.objects.filter(fprivate__contains = '1').filter(userupload=username).order_by('-fsize')
          psize_check = '0'
       elif psize_check == '0':
          psize_filter = File.objects.filter(fprivate__contains = '1').filter(userupload=username).order_by('fsize')
          psize_check = '1'
       else:
          psize_check = '1'
    return render(request, 'docfiles/download.html', {'all':size_filter, 'sizefiltervalue':size_check, 'pall':psize_filter, 'psizefiltervalue':psize_check})


def upload_log_view(request):
    total, used, free = shutil.disk_usage(settings.MEDIA_ROOT) 
    storage_exist = os.path.isdir(settings.MEDIA_ROOT + "/images");
    calc_total = total // (1024 * 1024 * 1024)
    calc_used =  used // (1024 * 1024)
    calc_free = free // (1024 * 1024 * 1024)
    display_total_space = ('Total_Space = %sGB'%calc_total)
    display_total_used = ('Space_Used = %sMB'%calc_used)
    display_total_free = ('Available_Space = %sGB'%calc_free)
    startdate = date.today() - timedelta(1)
    enddate = date.today()
    all_uploads = File.objects.filter(fprivate__contains='0').filter(uploaddate__range=[startdate, enddate])
    return render(request,'docfiles/main.html', {'allup':all_uploads, 'totalspace':display_total_space, 'spaceused':display_total_used, 'availablespace':display_total_free,'storageexist':storage_exist})

def lockout(request, credentials, *args, **kwargs):
    response = mail_admins('ALERT ATTEMPTED LOGIN FAIL: ACCOUNT LOCKED','TEST ALERT CONTENT')
    return HttpResponse('ATTEMPTED LOGIN FAIL DETECTED!\nYou have been locked out!%s'%response)
