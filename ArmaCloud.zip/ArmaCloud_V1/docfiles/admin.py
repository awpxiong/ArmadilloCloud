from django.contrib import admin
from .models import File
# Register your models here.

class FileAdmin(admin.ModelAdmin):
    list_display = ('id', 'admin_photo', 'uploaddate', 'upload', "fextension", "fname", "userupload", "fsize", "fprivate")
    list_filter = ('fextension','uploaddate')
    readonly_fields = ('uploaddate','admin_photo')

    def delete_queryset(self, request, queryset):
        for obj in queryset:
            obj.filedelete()

admin.site.register(File, FileAdmin)
