Priority Requirement
1) Make Directory (mkdir /home/pi/ArmaCloudDrive)
2) Make 2nd Directory to store media files (mkdir /home/pi/ArmaCloudDrive/images)
3) Mount your Harddrive or SSD
4) Configure the 'armacloud.conf' file with your ip address and directory that
you have extracted the armacloud files..

DO NOT EXECUTE THE INSTALLER.SH 
BEFORE YOU HAVE EDITED THE 'armacloud.conf' CONFIG FILE FOR APACHE
YOU NEED TO INPUT THE DIRECTORY OF ARMACLOUD INTO '/directory-of-armacloud/'

AND YOU WILL NEED TO INPUT YOUR OWN COMPUTER's IP ADDRESS
YOU CAN FIND OUT THE IP ADDRESS USING 'ifconfig' in the command shell

after you have done everything you can execute the installer.sh
by running the command './installer.sh' 

it will install every dependencies for you and setup everything.

after which you can access your cloud storage via website at your own
local ip address (for LAN)
external ip address (for Out of Lan Remote access)
